# seevars

Muestra las variables que en el prompt se declararon.